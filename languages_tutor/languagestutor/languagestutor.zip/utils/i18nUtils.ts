// utils/i18nUtils.ts
'use client';

import i18n from '@/app/i18n'; 
import Cookies from 'js-cookie';

export const languages = ['en', 'ar'] as const;
export type Language = (typeof languages)[number];

export const ARAB_COUNTRY_CODES = [
  'DZ', 'BH', 'KM', 'DJ', 'EG', 'IQ', 'JO', 'KW', 'LB',
  'LY', 'MR', 'MA', 'OM', 'PS', 'QA', 'SA', 'SO', 'SD',
  'SY', 'TN', 'AE', 'YE'
];

export const switchLang = (lang: Language) => {
  i18n.changeLanguage(lang);

  Cookies.set('i18next', lang, { expires: 30 });

  const currentPath = window.location.pathname;
  const pathWithoutLang = currentPath.replace(/^\/(en|ar)/, '');
  window.location.href = `/${lang}${pathWithoutLang}`;
};
