export const ARAB_COUNTRY_CODES = [
    'DZ', 'BH', 'KM', 'DJ', 'EG', 'IQ', 'JO', 'KW', 'LB',
    'LY', 'MR', 'MA', 'OM', 'PS', 'QA', 'SA', 'SO', 'SD',
    'SY', 'TN', 'AE', 'YE'
  ];
  