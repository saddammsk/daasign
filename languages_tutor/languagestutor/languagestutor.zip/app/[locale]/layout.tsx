import { hasLocale, NextIntlClientProvider } from 'next-intl';
import { getMessages } from 'next-intl/server';
import {routing} from '@/i18n/routing';
import { ReactNode } from 'react';
import type { Metadata } from "next";
import { Geist,  } from "next/font/google";
import "../globals.css";
import Navbar from "../components/common/Navbar";
import { Toaster } from 'react-hot-toast'
import { GlobalProvider } from "../context/GlobalContext";
import Footer from '../components/common/Footer';
import DemoFormPopup from '../components/DemoFormPopup';
import { notFound } from 'next/navigation';

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});


export const metadata: Metadata = {
    title: "LanguagesTutor",
    description: "Languages Tutor.",
    icons: {
      icon: '/favicon.png',
    },
  };

export default async function LocaleLayout({
  children,
  params,
}: {
  children: ReactNode;
  params: Promise<{ locale: string }>;
}) {

  const {locale} = await params;
  if (!hasLocale(routing.locales, locale)) {
    notFound();
  }

  const messages = await getMessages();


  return (
    <html lang={locale} dir={locale === 'ar' ? 'rtl' : 'ltr'}>
      <body className={`${geistSans.variable} font-geist antialiased`}>
        <NextIntlClientProvider locale={locale} messages={messages}>
        <GlobalProvider>
              <Navbar/>
              {children} 
              <Footer/>
              {/* <DemoFormPopup/> */}
              <Toaster
                position="top-right" 
                toastOptions={{
                  style: {
                    background: '#333',
                    color: '#fff',
                  },
                }}
              />
            </GlobalProvider>
        </NextIntlClientProvider>
      </body>
    </html>
  );
}
