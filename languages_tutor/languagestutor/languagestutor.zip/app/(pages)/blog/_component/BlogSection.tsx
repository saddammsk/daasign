'use client'
import React, { useEffect } from 'react'
import Asidebar from './Asidebar'
import SortBy from '@/app/components/SortBy'
import { urlFor } from '@/app/lib/sanityImage'
import { useGlobalContext } from '@/app/context/GlobalContext'
import Image from 'next/image'
import { BlogCard } from '@/app/components/BlogCard'
import SortByBlog from '@/app/components/SortByBlog'
import Translate from '@/app/components/common/Translate'


const BlogSection = () => {
    const {filteredBlog} = useGlobalContext();
    const [loading, setLoading] = React.useState(true)
    

  useEffect(()=>{
    if(filteredBlog){
        setLoading(false)
    }else{
        setLoading(true)
    }

  },[filteredBlog])

  return (
      <section className='lg:py-20 py-10'>
               <div className="w-full max-w-[1340px] px-5 mx-auto">
                   <div className="w-full flex lg:flex-row flex-col gap-8">
                      <Asidebar/>
                       <div className="lg:w-[calc(100%_-_212px)] w-full">
                           <div className="w-full flex items-center justify-between gap-5 mb-6">
                               <h3 className='text-lg lg:block hidden text-neutral2 font-semibold'><Translate tKey="all_blogs" Tag="span" /></h3>
                               <SortByBlog/>
                           </div>
                     
                           <div className="w-full grid md:grid-cols-3 grid-cols-1 gap-4">
                          {filteredBlog
                           .map((blog:any) => (
                           <BlogCard key={blog.title}
                           href={`/blog/${blog.slug}`}
                           img={urlFor(blog?.mainImage).width(400).url()} 
                           authorImage={urlFor(blog?.writer?.image).width(400).url()} 
                           title={blog?.title} 
                           authorName={blog?.name} 
                           blogCategory={blog?.blogCategory[0].title} 
                           createdAt={blog?.createdAt} 
                           description={blog?.description} 
                           />
                           ))}
                           </div>
                           {loading && (
                              <div className="w-full grid md:grid-cols-3 grid-cols-1 gap-4">
                                {[1, 2, 3, 4, 5, 6].map((i) => (
                                  <div
                                    key={i}
                                    className="animate-pulse bg-white rounded-xl shadow p-4 flex flex-col gap-4 min-h-[320px] border border-neutral4"
                                  >
                                    <div className="bg-gray-200 h-[224px] w-full rounded-lg" />
                                    <div className="h-6 bg-gray-200 rounded w-3/4" />
                                    <div className="h-4 bg-gray-200 rounded w-1/2" />
                                    <div className="flex gap-2 mt-auto">
                                      <div className="h-4 w-12 bg-gray-200 rounded" />
                                      <div className="h-4 w-16 bg-gray-200 rounded" />
                                    </div>
                                  </div>
                                ))}
                              </div>
                            )}
                 
                       </div>
                   </div>
                   
               </div>
           </section>
  )
}

export default BlogSection