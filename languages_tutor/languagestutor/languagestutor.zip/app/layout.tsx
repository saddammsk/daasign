
import type { Metadata } from "next";
import { Geist,  } from "next/font/google";
import "./globals.css";
import { Navbar } from "./components/common/Navbar";
import DiscountPopup from "./components/DiscountPopup";
import Footer from "./components/common/Footer";
import { Toaster } from 'react-hot-toast'
import { GlobalProvider } from "./context/GlobalContext";
import DemoFormPopup from "./components/DemoFormPopup";
import I18nProvider from './components/I18nProvider';
import { languages } from '@/utils/i18nUtils';
import type { ReactNode } from "react";

const geistSans = Geist({
  variable: "--font-geist-sans",
  subsets: ["latin"],
});

export function generateStaticParams() {
  return languages.map(lang => ({ lang }));
}

function dir(lang: string) {
  return lang === 'ar' ? 'rtl' : 'ltr';
}

export const metadata: Metadata = {
  title: "LanguagesTutor",
  description: "Languages Tutor.",
  icons: {
    icon: '/favicon.png',
  },
};

export default function LangLayout({ children, params }: { children: ReactNode; params: { lang: string } }) {
  return (
    <html lang={params.lang} dir={params.lang === 'ar' ? 'rtl' : 'ltr'}>
      <body className={`${geistSans.variable} font-geist antialiased`}>
        <I18nProvider>
            <GlobalProvider>
              <Navbar/>
              {children} 
              <Footer/>
              <DemoFormPopup/>
              <Toaster
                position="top-right" 
                toastOptions={{
                  style: {
                    background: '#333',
                    color: '#fff',
                  },
                }}
              />
            </GlobalProvider>
            {/* <DiscountPopup/> */}
        </I18nProvider>
      </body>
    </html>
  );
}
