import React from 'react'

const NewTeamSidebar = () => {
  return (
    <div>NewTeamSidebar</div>
  )
}

export default NewTeamSidebar